ELECTROFORGE AI — ANDROID APK CLOUD BUILDER

This package builds a basic installable Android app using GitHub Actions.
You only need an Android phone and a GitHub account.

IMPORTANT:
- This is a starter Android app with an offline mobile dashboard.
- It is not yet connected to an AI model or a real circuit simulator.
- The APK is created by GitHub Actions; this ZIP is NOT itself an APK.

PHONE UPLOAD:
1. Extract this ZIP using your Android Files app.
2. Open https://github.com/YOUR-USERNAME/ElectroForge-AI
3. Tap Add file > Upload files.
4. Upload ALL files and folders from the extracted package.
   Make sure the .github folder is included. If hidden folders are not
   visible, use GitHub's web editor to create the workflow file manually.
5. Commit the files to the main branch.
6. Open the repository's Actions tab.
7. Select "Build ElectroForge AI APK", then tap "Run workflow".
8. Wait for the workflow to finish successfully.
9. Open the completed workflow run, scroll to Artifacts, and download
   ElectroForge-AI-debug-apk.
10. Extract the downloaded artifact ZIP and tap the .apk file to install.

If Android blocks installation, allow Chrome or Files to install unknown apps
in Android Settings. Only install APKs you built from your own repository.

PACKAGE NAME: com.electroforge.ai
